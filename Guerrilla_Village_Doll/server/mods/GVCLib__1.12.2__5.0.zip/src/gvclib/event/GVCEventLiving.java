package gvclib.event;

import java.util.List;

import gvclib.mod_GVCLib;
import gvclib.entity.living.EntityGVCLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class GVCEventLiving {
	@SubscribeEvent
	public void onUpdateEvent_Debag(WorldEvent.Unload event) {
		
		if(mod_GVCLib.cfg_mobdismount_insave) {
			World world = event.getWorld();
			List<Entity> entitylist = world.loadedEntityList;
			if (entitylist != null) {
				for (int lj = 0; lj < entitylist.size(); lj++) {
					Entity entity1 = (Entity) entitylist.get(lj);
					if (entity1.canBeCollidedWith()) {
						if(entity1 != null && entity1 instanceof EntityGVCLivingBase) {
							if (entity1.isRiding()) {
								entity1.dismountRidingEntity();
							}
						}
					}
				}
			}
		}
		
	}
}
